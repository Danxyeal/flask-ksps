from server import app, db
from server.models import ProductScrape
from ksps.scrapers import VendorScraper
from flask_sqlalchemy import SQLAlchemy

def scrape_asus(vendor_id, part_id):
    if ProductScrape.objects(partId=part_id):
        return f'Part {part_id} previously scraped'
    scraper = VendorScraper(vendor_id)
    result = scraper.search_part(part_id)
    if not result:
        return f'Part {part_id} was not found in vendor\'s catalog'
    ProductScrape(partId=part_id, vendorId=vendor_id, scrapedUrl=result[0], rawText=result[1]).save()
    return f'Part {part_id} was scraped and stored in NoSQL'

