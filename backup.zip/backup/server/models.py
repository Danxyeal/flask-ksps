import flask
from server import db, pg
from sqlalchemy import Column, Integer, String

# Mongo DB Models
class ProductScrape(db.Document):
    partId = db.StringField(unique=True)
    vendorId = db.StringField(max_length=30)
    scrapedUrl = db.StringField(max_length=200)
    rawText = db.StringField(max_length=2147483647)

# PostgreSQL Models
class Vendors(pg.Model):
    __tablename__ = 'vendors'
    vendorId = Column(Integer, primary_key = True)
    code = Column(String)
    name = Column(String)
    webSite = Column(String)
