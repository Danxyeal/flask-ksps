from flask import request, jsonify
from server import app, db, pg
from server.models import ProductScrape
from server.controllers import scrape_asus
from ksps.scrapers import VendorScraper

@app.cli.command('create_pg')
def create_pg():
    pg.create_all()
    print('PostgreSQL database seeded')

@app.route('/')
@app.route('/index')
def index():
    return jsonify(message='Experimental scraper is ready.'), 200

@app.route('/scrape/<string:vendor_id>/<string:part_id>')
def scrape(vendor_id: str, part_id: str):
    print(f'Scraping {vendor_id} for part {part_id}...')
    result = scrape_asus(vendor_id, part_id)
    return jsonify(result=result), 201

@app.route('/products')
def get_all_products():
    return jsonify(ProductScrape.objects.all()), 200

@app.route('/products/<string:part_id>')
def get_one_product(part_id: str):
    return jsonify(ProductScrape.objects.get_or_404(partId=part_id))

