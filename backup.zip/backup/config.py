import os

class Config(object):
    SECRET_KEY = os.environ.get('SECRET_KEY') or "secret_string"
    MONGODB_SETTINGS = { 'db': 'ksps01_db' }
    POSTGRES_DB = 'ksps01_pg'
    PGH = os.environ.get('POSTGRES_HOST')
    PGU = os.environ.get('POSTGRES_USER')
    PGP = os.environ.get('POSTGRES_PASSWORD')
    SQLALCHEMY_DATABASE_URI = f'postgresql+psycopg2://{PGU}:{PGP}@{PGH}/{POSTGRES_DB}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    #POSTGRES_ = os.environ.get('POSTGRES_')
    #POSTGRES_ = os.environ.get('POSTGRES_')
