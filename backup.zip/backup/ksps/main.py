from search_scrape import SearchAsus

def main():
    scrape = SearchAsus()
    scrape.search_part('MB16AC')

if __name__ == "__main__":
    print('Scraping..')
    main()

