import time
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from requests.exceptions import HTTPError

class SearchScrape:
    """
    Class for using a search page and scraping the results
        self.url:string of the url of the search page
        self.result_tag: html tag used to find search results
        self.wait_tag: css class that selenium looks for to check the results are loaded
        self.query: string to be searched
        self.browser: selenium browser config
    """

    def __init__(self, url, wait_tag, result_tag):
        self.url = url
        self.result_tag = result_tag
        self.wait_tag = wait_tag
        self.browser = self.init_browser()
        self.query = ''

    def search_query(self, query):
        """
        Method for loading a search page in the selenium browser
        """
        self.query = query
        self.browser.get(f"{self.url}{query}")
        selenium_success = True
        wait = WebDriverWait(self.browser, 2)
        class_and_tag = (By.CLASS_NAME, self.wait_tag)
        ec = EC.visibility_of_element_located(class_and_tag)
        try:
            wait.until(ec)
        except TimeoutException:
            print("Timed out waiting for page to load")
            selenium_success = False
        
        if selenium_success == True:
            html = self.browser.page_source
            self.browser.get("about:blank")
            return html
        return False

    def sort_results(self, search_page):
        """
        Takes the html from the search page finds the search results and
        puts them into a list of dictionaries containing the page name and url
        """
        soup = BeautifulSoup(search_page, 'html.parser')
        results_row = soup.find_all(self.result_tag)
        results = []

        for result_row in results_row:
            #consider error handling if bs4 can't find tags 
            page = result_row.getText()
            url = result_row.parent.get('href')
            results.append({
                "name": page,
                "url": url
            })
        
        if results:
            return results
        print('no results found')
        return False
    
    def init_browser(self):
        '''
        Initialise the browser for the selenium web scraper
        '''
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--incognito')
        # path = r'C:/Program Files (x86)/Google/Chrome/Application/chromedriver.exe'
        path = r'/bin/chromedriver'
        return webdriver.Chrome(executable_path=path, options=options)


class VendorScraper:
    """
    Uses SearchScrape to scrape from the asus.com search page and
    then find an exact match for the vendor part and scrape that parts page
    self.vendor: The vendor of the part to be searched
    self.url: The url for asus.com search
    self.wait_tag: css class that selenium looks for to check the results are loaded
    self.result_tag: html tag used to find search results
    self.browser: config for selenium browser
    self.query: vendor part being searched for
    """
    def __init__(self, vendor_id):
        self.vendor = vendor_id
        self.url = self.set_vendor()
        self.wait_tag = 'product-name'
        self.result_tag = 'h2'
        self.browser = ''
        self.query = ''

    def set_vendor(self):
        if self.vendor == 'ASUS':
            return 'https://www.asus.com/au/search/results.aspx?SearchKey='
        else:
            return 'https://www.hp.com'

    def search_part(self, query):
        """
        Calls the SearchScrape class and uses its methods and scrape_exact_match to open the asus search page,
        search a vendor part, find the matching page and then scrape the specifications page for that vendor part.
        query: vendor part to be searched
        """
        scrape = SearchScrape(self.url, self.wait_tag, self.result_tag)
        self.browser = scrape.browser
        self.query = query
        scrape_list = [scrape.search_query, scrape.sort_results, self.scrape_exact_match]
        for method in scrape_list:
            query = method(query)
            if not query:
                break
        return query

    def scrape_exact_match(self, search_results):
        """
        Looks through the list of search results find an exact match
        and scrapes the specifications page for the vendor part
        """
        count = 0
        for result in search_results:
            if result["name"] == self.query:
                count += 1
                match_url = result["url"]
        if count >= 1:
            self.browser.get(f'{match_url}specifications/')
            soup = BeautifulSoup(self.browser.page_source, 'html.parser').get_text().replace('\n','')
            return (match_url, soup)
        if count == 0:
            print("No match found")
            return False
        if count > 2:
            print("Name is too common")
            return False
        print("Search timed out")
        return False

if __name__ == ('__main__'):
    scrape_asus = VendorScraper('ASUS')
    scrape_asus.search_part('90IG04Q0-MFAR20')

